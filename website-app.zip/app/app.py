import os
import socket
from datetime import datetime, timezone

from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Set by Jenkins at deploy time (docker run -e APP_VERSION=<build number>)
APP_VERSION = os.getenv("APP_VERSION", "local")
STARTED_AT = datetime.now(timezone.utc).strftime("%d %b %Y, %H:%M UTC")


@app.context_processor
def inject_globals():
    # Available in every template
    return {
        "app_version": APP_VERSION,
        "started_at": STARTED_AT,
        "hostname": socket.gethostname(),
        "year": datetime.now().year,
    }


@app.route("/")
def home():
    return render_template("index.html", active="home")


@app.route("/pipeline")
def pipeline():
    stages = [
        ("Checkout", "Jenkins pulls the latest code from GitHub (main branch).", "📥"),
        ("Build Image", "Docker builds a new image tagged with the Jenkins build number.", "🐳"),
        ("Push", "The image is pushed to Docker Hub with the build tag and :latest.", "📦"),
        ("Deploy", "Jenkins connects to the app server over SSH and swaps the running container.", "🚀"),
        ("Health Check", "curl checks the site responds. If not, the build fails.", "✅"),
    ]
    return render_template("pipeline.html", active="pipeline", stages=stages)


@app.route("/stack")
def stack():
    tools = [
        ("AWS EC2", "Two Ubuntu servers in ap-south-1: one for Jenkins, one for the app.", "☁️"),
        ("Terraform", "Creates the app server, security group and SSH key pair as code.", "🏗️"),
        ("Jenkins", "Runs the declarative pipeline defined in the Jenkinsfile.", "⚙️"),
        ("Docker", "Packages this website into a portable image.", "🐳"),
        ("Docker Hub", "Stores every version of the image.", "📦"),
        ("GitHub", "Holds the code and triggers Jenkins through a webhook.", "🐙"),
        ("Flask + Gunicorn", "Python web framework served by a production WSGI server.", "🐍"),
    ]
    return render_template("stack.html", active="stack", tools=tools)


@app.route("/contact", methods=["GET", "POST"])
def contact():
    sent = False
    name = ""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        sent = True  # demo only: messages are not stored
    return render_template("contact.html", active="contact", sent=sent, name=name)


@app.route("/health")
def health():
    # Used by the Jenkins health check and for monitoring
    return jsonify(status="ok", version=APP_VERSION, host=socket.gethostname())


@app.errorhandler(404)
def not_found(_):
    return render_template("404.html", active=""), 404


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
